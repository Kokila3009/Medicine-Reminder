package com.kokila.medicinetime.alarm;

import com.kokila.medicinetime.BasePresenter;
import com.kokila.medicinetime.BaseView;
import com.kokila.medicinetime.data.source.History;
import com.kokila.medicinetime.data.source.MedicineAlarm;

/**
 * Created by gautam on 13/07/17.
 */

public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
